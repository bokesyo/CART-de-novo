
from regreCalcSinglePointer import *
from inputData import *


def getPointerData(pointer_num, id_list):
    out_list = []
    for lid in id_list:
        list_by_id = data_dict[lid]
        component = list_by_id[0]
        target = list_by_id[1]

        data_by_pointer = component[pointer_num]
        id_data = data_by_pointer

        prep = [id_data, target]
        out_list.append(prep)
    return out_list

# 返回一个含有全部 指定指标数值 的列表


# 生成初始指标列表
def init_pointer():
    global pointer_used
    pointer_used = {}
    length_ini = len(data_dict[1][0])
    for i in range(0, length_ini):
        pointer_used[i] = 0
    print(pointer_used)


def generatePermitPointer():
    global permit_pointer
    permit_pointer = []
    for j in pointer_used:
        # 假设最大深度是 2 ：每个指标最多能用两次
        if pointer_used[j] <= 2:
            permit_pointer.append(j)
    print(permit_pointer)


def pointerChoose(id_list):

    # 装入各个指标的方差
    result_by_pointer_list = []

    # 生成可用指标列表
    generatePermitPointer()

    # 对每个可用指标进行计算
    # print(permit_pointer)
    for pointer in permit_pointer:
        # 对每个指标生成一个列表
        data_list_by_pointer = getPointerData(pointer, id_list)
        #
        result_by_pointer = [pointer] + cutPointChoose(data_list_by_pointer)
        # print(result_by_pointer)
        print(result_by_pointer)
        result_by_pointer_list.append(result_by_pointer)

    # 找到最优指标 和 切分值
    result_min_pointer = None
    for result_pointer in result_by_pointer_list:
        if not result_min_pointer:
            result_min_pointer = result_pointer

        else:
            if result_pointer[2] <= result_min_pointer[2]:
                result_min_pointer = result_pointer
    print('min', result_min_pointer)
    return result_min_pointer

    # 返回最小方差所对应的指标


def test(i):
    generatePermitPointer()

    # Prepare id list

    # print(id_list)

    # Test
    pointer_t = i
    data_list_by_pointer = getPointerData(pointer_t, id_list)

    result_by_pointer = [pointer_t] + cutPointChoose(data_list_by_pointer)

    print(result_by_pointer)


# Initialize
data_dict = readCSV()

# Prepare pointer
init_pointer()

id_list = list(range(0, len(data_dict)))

pointerChoose(id_list)


